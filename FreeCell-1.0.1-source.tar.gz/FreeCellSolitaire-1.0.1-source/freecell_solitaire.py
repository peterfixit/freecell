#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
import os
import random
import time
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import messagebox, ttk

APP_NAME = "FreeCell Solitaire"
APP_VERSION = "1.0.1"

SUITS = ["♠", "♥", "♦", "♣"]
SUIT_COLORS = {"♠": "#11161a", "♣": "#11161a", "♥": "#c62828", "♦": "#c62828"}
RANK_LABELS = {1: "A", 11: "J", 12: "Q", 13: "K"}
DIFFICULTIES = ("Easy", "Normal", "Hard")
ACCENT_COLORS = {
    "Blue": "#1f5fae", "Red": "#b53a46", "Green": "#23795a",
    "Purple": "#7046a8", "Black": "#303840", "Orange": "#c86a1c",
}
BACKGROUND_COLORS = {
    "Classic Green": ("#0b6b4a", "#064936", "#064534", "#7ab596"),
    "Forest": ("#174f3b", "#10382b", "#0d3528", "#719b88"),
    "Midnight Blue": ("#173a5e", "#0d263f", "#102d49", "#7594b0"),
    "Burgundy": ("#6a2d3e", "#431c29", "#4f2230", "#ad7886"),
    "Slate": ("#3e4b56", "#29333b", "#303a43", "#82909b"),
    "Purple": ("#503768", "#352445", "#3c2a4e", "#927ca5"),
    "Teal": ("#12636a", "#0b4146", "#0e4a50", "#78aeb2"),
    "Charcoal": ("#292f34", "#1b2024", "#20262a", "#727b82"),
}


def rank_text(rank: int) -> str:
    return RANK_LABELS.get(rank, str(rank))


def color_of(suit: str) -> str:
    return "red" if suit in ("♥", "♦") else "black"


def data_dir() -> Path:
    base = os.environ.get("XDG_DATA_HOME")
    p = Path(base) / "FreeCellSolitaire" if base else Path.home() / ".local" / "share" / "FreeCellSolitaire"
    p.mkdir(parents=True, exist_ok=True)
    return p


@dataclass
class Card:
    rank: int
    suit: str

    def to_dict(self):
        return {"rank": self.rank, "suit": self.suit}

    @classmethod
    def from_dict(cls, d):
        return cls(int(d["rank"]), str(d["suit"]))


class FreeCellGame:
    def __init__(self, difficulty: str = "Normal"):
        self.difficulty = difficulty if difficulty in DIFFICULTIES else "Normal"
        self.cascades: list[list[Card]] = [[] for _ in range(8)]
        self.freecells: list[Card | None] = [None] * 4
        self.foundations: dict[str, list[Card]] = {s: [] for s in SUITS}
        self.moves = 0
        self.history: list[dict] = []
        self.start_time = time.time()
        self.end_time: float | None = None
        self.new_game(self.difficulty)

    @staticmethod
    def _base_deck() -> list[Card]:
        return [Card(rank, suit) for suit in SUITS for rank in range(1, 14)]

    @staticmethod
    def _deal(deck: list[Card]) -> list[list[Card]]:
        cols = [[] for _ in range(8)]
        for i, card in enumerate(deck):
            cols[i % 8].append(card)
        return cols

    @classmethod
    def _deal_score(cls, deck: list[Card]) -> int:
        """Heuristic used only to bias random deals toward friendlier/tougher starts."""
        cols = cls._deal(deck)
        score = 0
        tops = [col[-1] for col in cols]

        # Low cards close to the playable top make foundations easier to start.
        for col in cols:
            for idx, card in enumerate(col):
                depth = len(col) - 1 - idx
                if card.rank <= 5:
                    score += max(0, 8 - depth) * (7 - card.rank) * 2
                if card.rank == 1:
                    score += max(0, 12 - depth * 2)

        # Reward immediate alternating descending joins and Aces/Twos on top.
        for i, src in enumerate(tops):
            if src.rank == 1:
                score += 70
            elif src.rank == 2:
                score += 35
            elif src.rank <= 4:
                score += 12
            for j, dst in enumerate(tops):
                if i != j and dst.rank == src.rank + 1 and color_of(dst.suit) != color_of(src.suit):
                    score += 16

        # Reward useful runs already present at the bottoms of columns.
        for col in cols:
            run = 1
            for i in range(len(col) - 1, 0, -1):
                a, b = col[i - 1], col[i]
                if a.rank == b.rank + 1 and color_of(a.suit) != color_of(b.suit):
                    run += 1
                else:
                    break
            score += (run - 1) * 9
        return score

    def _deck(self, difficulty: str) -> list[Card]:
        base = self._base_deck()
        if difficulty == "Normal":
            random.shuffle(base)
            return base
        choose_high = difficulty == "Easy"
        chosen = None
        chosen_score = None
        for _ in range(260):
            cand = [Card(c.rank, c.suit) for c in base]
            random.shuffle(cand)
            score = self._deal_score(cand)
            if chosen_score is None or (choose_high and score > chosen_score) or (not choose_high and score < chosen_score):
                chosen, chosen_score = cand, score
        return chosen or base

    def new_game(self, difficulty: str | None = None):
        if difficulty in DIFFICULTIES:
            self.difficulty = difficulty
        deck = self._deck(self.difficulty)
        self.cascades = self._deal(deck)
        self.freecells = [None] * 4
        self.foundations = {s: [] for s in SUITS}
        self.moves = 0
        self.history = []
        self.start_time = time.time()
        self.end_time = None

    def snapshot(self):
        return {
            "cascades": [[c.to_dict() for c in col] for col in self.cascades],
            "freecells": [c.to_dict() if c else None for c in self.freecells],
            "foundations": {s: [c.to_dict() for c in cards] for s, cards in self.foundations.items()},
            "moves": self.moves,
            "elapsed": self.elapsed_seconds(),
            "end_time": self.end_time,
        }

    def restore(self, snap):
        self.cascades = [[Card.from_dict(c) for c in col] for col in snap["cascades"]]
        self.freecells = [Card.from_dict(c) if c else None for c in snap["freecells"]]
        self.foundations = {s: [Card.from_dict(c) for c in snap["foundations"].get(s, [])] for s in SUITS}
        self.moves = int(snap["moves"])
        elapsed = int(snap.get("elapsed", 0))
        self.start_time = time.time() - elapsed
        self.end_time = snap.get("end_time")

    def push_history(self):
        self.history.append(copy.deepcopy(self.snapshot()))
        if len(self.history) > 600:
            self.history.pop(0)

    def undo(self):
        if not self.history:
            return False
        self.restore(self.history.pop())
        self.end_time = None
        return True

    def elapsed_seconds(self):
        end = self.end_time if self.end_time is not None else time.time()
        return max(0, int(end - self.start_time))

    @staticmethod
    def valid_sequence(cards: list[Card]) -> bool:
        if not cards:
            return False
        for a, b in zip(cards, cards[1:]):
            if a.rank != b.rank + 1 or color_of(a.suit) == color_of(b.suit):
                return False
        return True

    def movable_sequence(self, col: int, idx: int) -> bool:
        return 0 <= col < 8 and 0 <= idx < len(self.cascades[col]) and self.valid_sequence(self.cascades[col][idx:])

    def empty_freecells(self) -> int:
        return sum(c is None for c in self.freecells)

    def empty_cascades(self) -> int:
        return sum(not col for col in self.cascades)

    def move_capacity(self, dst: int) -> int:
        # Standard FreeCell "supermove" capacity. An empty destination column
        # cannot also be counted as temporary working space for that same move.
        empty_cols = self.empty_cascades() - (1 if not self.cascades[dst] else 0)
        empty_cols = max(0, empty_cols)
        return (self.empty_freecells() + 1) * (2 ** empty_cols)

    def can_cascade_to_cascade(self, src: int, idx: int, dst: int) -> bool:
        # A correctly built descending alternating-colour run may be moved as
        # one unit.  The UI is deliberately permissive here: it does not reject
        # a valid run merely because there are too few temporary Free Cells or
        # empty cascades to reproduce the move one card at a time.
        if src == dst or not self.movable_sequence(src, idx):
            return False
        moving = self.cascades[src][idx:]
        target = self.cascades[dst]
        if not target:
            return True
        top = target[-1]
        first = moving[0]
        return top.rank == first.rank + 1 and color_of(top.suit) != color_of(first.suit)

    def move_cascade_to_cascade(self, src: int, idx: int, dst: int) -> bool:
        if not self.can_cascade_to_cascade(src, idx, dst):
            return False
        self.push_history()
        moving = self.cascades[src][idx:]
        del self.cascades[src][idx:]
        self.cascades[dst].extend(moving)
        self.moves += 1
        self._check_win()
        return True

    def can_cascade_to_freecell(self, src: int, cell: int) -> bool:
        return 0 <= cell < 4 and self.freecells[cell] is None and bool(self.cascades[src])

    def move_cascade_to_freecell(self, src: int, cell: int) -> bool:
        if not self.can_cascade_to_freecell(src, cell):
            return False
        self.push_history()
        self.freecells[cell] = self.cascades[src].pop()
        self.moves += 1
        return True

    def can_freecell_to_cascade(self, cell: int, dst: int) -> bool:
        c = self.freecells[cell]
        if c is None:
            return False
        target = self.cascades[dst]
        return (not target) or (target[-1].rank == c.rank + 1 and color_of(target[-1].suit) != color_of(c.suit))

    def move_freecell_to_cascade(self, cell: int, dst: int) -> bool:
        if not self.can_freecell_to_cascade(cell, dst):
            return False
        self.push_history()
        self.cascades[dst].append(self.freecells[cell])
        self.freecells[cell] = None
        self.moves += 1
        self._check_win()
        return True

    def can_to_foundation(self, card: Card) -> bool:
        pile = self.foundations[card.suit]
        return (not pile and card.rank == 1) or (pile and pile[-1].rank + 1 == card.rank)

    def move_cascade_to_foundation(self, src: int) -> bool:
        if not self.cascades[src]:
            return False
        c = self.cascades[src][-1]
        if not self.can_to_foundation(c):
            return False
        self.push_history()
        self.foundations[c.suit].append(self.cascades[src].pop())
        self.moves += 1
        self._check_win()
        return True

    def move_freecell_to_foundation(self, cell: int) -> bool:
        c = self.freecells[cell]
        if c is None or not self.can_to_foundation(c):
            return False
        self.push_history()
        self.foundations[c.suit].append(c)
        self.freecells[cell] = None
        self.moves += 1
        self._check_win()
        return True

    def can_foundation_to_cascade(self, suit: str, dst: int) -> bool:
        if not self.foundations[suit]:
            return False
        c = self.foundations[suit][-1]
        target = self.cascades[dst]
        return (not target) or (target[-1].rank == c.rank + 1 and color_of(target[-1].suit) != color_of(c.suit))

    def move_foundation_to_cascade(self, suit: str, dst: int) -> bool:
        if not self.can_foundation_to_cascade(suit, dst):
            return False
        self.push_history()
        self.cascades[dst].append(self.foundations[suit].pop())
        self.moves += 1
        self.end_time = None
        return True

    def foundation_rank(self, suit: str) -> int:
        return self.foundations[suit][-1].rank if self.foundations[suit] else 0

    def auto_complete_foundations(self) -> int:
        def candidates():
            out = []
            for cell, c in enumerate(self.freecells):
                if c is not None and self.can_to_foundation(c):
                    out.append((c.rank, 0, "cell", cell, c.suit))
            for src, col in enumerate(self.cascades):
                if col and self.can_to_foundation(col[-1]):
                    c = col[-1]
                    out.append((c.rank, 1, "cascade", src, c.suit))
            return sorted(out)

        todo = candidates()
        if not todo:
            return 0
        self.push_history()
        moved = 0
        while todo:
            _rank, _prio, kind, src, suit = todo[0]
            if kind == "cell":
                c = self.freecells[src]
                self.freecells[src] = None
            else:
                c = self.cascades[src].pop()
            self.foundations[suit].append(c)
            moved += 1
            todo = candidates()
        self.moves += moved
        self._check_win()
        return moved

    def _check_win(self):
        if sum(len(v) for v in self.foundations.values()) == 52 and self.end_time is None:
            self.end_time = time.time()

    @property
    def won(self):
        return sum(len(v) for v in self.foundations.values()) == 52


class StatsStore:
    def __init__(self):
        self.path = data_dir() / "stats.json"
        self.settings_path = data_dir() / "settings.json"
        self.stats = self._load(self.path, {})
        defaults = {"difficulty": "Normal", "accent": "Blue", "background": "Charcoal"}
        self.settings = self._load(self.settings_path, defaults)
        for k, v in defaults.items():
            self.settings.setdefault(k, v)

    @staticmethod
    def _load(path, default):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
            return obj if isinstance(obj, dict) else copy.deepcopy(default)
        except Exception:
            return copy.deepcopy(default)

    @staticmethod
    def _save(path, obj):
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(obj, indent=2), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def default_stat():
        return {"played": 0, "won": 0, "best_time": None, "fewest_moves": None, "current_streak": 0, "best_streak": 0}

    def save_settings(self):
        self._save(self.settings_path, self.settings)

    def reset_stats(self):
        self.stats = {}
        self._save(self.path, self.stats)

    def record_started(self, diff):
        s = self.stats.setdefault(diff, self.default_stat())
        s["played"] += 1
        self._save(self.path, self.stats)

    def record_win(self, diff, seconds, moves):
        s = self.stats.setdefault(diff, self.default_stat())
        s["won"] += 1
        s["current_streak"] += 1
        s["best_streak"] = max(s["best_streak"], s["current_streak"])
        if s["best_time"] is None or seconds < s["best_time"]:
            s["best_time"] = seconds
        if s["fewest_moves"] is None or moves < s["fewest_moves"]:
            s["fewest_moves"] = moves
        self._save(self.path, self.stats)

    def record_loss(self, diff):
        s = self.stats.setdefault(diff, self.default_stat())
        s["current_streak"] = 0
        self._save(self.path, self.stats)

    def get(self, diff):
        out = self.default_stat()
        out.update(self.stats.get(diff, {}))
        return out


class FreeCellApp(tk.Tk):
    CARD_FACE = "#fffef9"
    CARD_EDGE = "#aeb8b3"
    HINT_SOURCE = "#ffd54f"
    HINT_DEST = "#5de0a4"
    TEXT = "#f7fbf9"

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1380x860")
        self.minsize(860, 620)
        self.store = StatsStore()
        self.current_difficulty = self.store.settings.get("difficulty", "Normal")
        if self.current_difficulty not in DIFFICULTIES:
            self.current_difficulty = "Normal"
        self.accent_name = self.store.settings.get("accent", "Blue")
        if self.accent_name not in ACCENT_COLORS:
            self.accent_name = "Blue"
        self.background_name = self.store.settings.get("background", "Charcoal")
        if self.background_name not in BACKGROUND_COLORS:
            self.background_name = "Charcoal"
        self._load_background_theme()

        self.game = FreeCellGame(self.current_difficulty)
        self.win_recorded = False
        self._icon_image = None
        self.card_rects = {}
        self.freecell_rects = {}
        self.foundation_rects = {}
        self.hitboxes = []
        self.cascade_drop_rects = {}

        self.hint_kind = None
        self.hint_payload = None
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        self.hint_anim_job = None
        self.hint_board_signature = None
        self.hint_cycle_index = 0

        self._set_window_icon()
        self._build_ui()
        self.bind_all("<Control-z>", lambda _e: self.undo())
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(250, self._tick)
        self.after(50, self._new_game_initial)

    def _load_background_theme(self):
        self.TABLE, self.TABLE_DARK, self.CARD_SHADOW, self.SLOT_EDGE = BACKGROUND_COLORS[self.background_name]

    def _set_window_icon(self):
        try:
            p = Path(__file__).with_name("freecell.png")
            if p.exists():
                self._icon_image = tk.PhotoImage(file=str(p))
                self.iconphoto(True, self._icon_image)
        except tk.TclError:
            pass

    def _build_ui(self):
        self.configure(bg=self.TABLE_DARK)
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Top.TButton", font=("DejaVu Sans", 10, "bold"), padding=(10, 5))
        style.configure("TCombobox", padding=3)

        top = tk.Frame(self, bg=self.TABLE_DARK, padx=10, pady=8)
        top.pack(fill="x", side="top")
        row1 = tk.Frame(top, bg=self.TABLE_DARK)
        row1.pack(fill="x")
        ttk.Button(row1, text="New Game", command=self.request_new_game, style="Top.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(row1, text="Statistics", command=self.show_statistics, style="Top.TButton").pack(side="left")
        self.status = tk.Label(row1, bg=self.TABLE_DARK, fg=self.TEXT, font=("DejaVu Sans", 11, "bold"), anchor="e")
        self.status.pack(side="right", fill="x", expand=True)

        row2 = tk.Frame(top, bg=self.TABLE_DARK)
        row2.pack(fill="x", pady=(7, 0))
        tk.Label(row2, text="Difficulty", bg=self.TABLE_DARK, fg=self.TEXT).pack(side="left", padx=(0, 5))
        self.diff_var = tk.StringVar(value=self.current_difficulty)
        cb = ttk.Combobox(row2, textvariable=self.diff_var, values=DIFFICULTIES, state="readonly", width=8)
        cb.pack(side="left", padx=(0, 12))
        cb.bind("<<ComboboxSelected>>", self.change_difficulty)

        tk.Label(row2, text="Accent", bg=self.TABLE_DARK, fg=self.TEXT).pack(side="left", padx=(0, 5))
        self.accent_var = tk.StringVar(value=self.accent_name)
        cb2 = ttk.Combobox(row2, textvariable=self.accent_var, values=list(ACCENT_COLORS), state="readonly", width=8)
        cb2.pack(side="left", padx=(0, 12))
        cb2.bind("<<ComboboxSelected>>", self.change_accent)

        tk.Label(row2, text="Background", bg=self.TABLE_DARK, fg=self.TEXT).pack(side="left", padx=(0, 5))
        self.background_var = tk.StringVar(value=self.background_name)
        cb3 = ttk.Combobox(row2, textvariable=self.background_var, values=list(BACKGROUND_COLORS), state="readonly", width=14)
        cb3.pack(side="left")
        cb3.bind("<<ComboboxSelected>>", self.change_background)
        tk.Label(row2, text="Easy = friendlier deals   •   Hard = tougher deals", bg=self.TABLE_DARK, fg="#d8e4de").pack(side="right")

        self.canvas = tk.Canvas(self, bg=self.TABLE, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda _e: self.after_idle(self.draw))
        self.canvas.bind("<Button-1>", self.on_click)

        self.bottom = tk.Frame(self, bg=self.TABLE_DARK, padx=10, pady=8)
        self.bottom.pack(fill="x", side="bottom")
        ttk.Button(self.bottom, text="↶  Back", command=self.undo, style="Top.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(self.bottom, text="Hint", command=self.show_hint, style="Top.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(self.bottom, text="Auto Complete", command=self.auto_complete, style="Top.TButton").pack(side="left", padx=(0, 10))
        self.hint = tk.Label(
            self.bottom, bg=self.TABLE_DARK, fg="#e3ece7",
            text="Single-click a card or valid stack to make its best legal move. Ctrl+Z also goes back.",
            anchor="w", padx=2, pady=6,
        )
        self.hint.pack(side="left", fill="x", expand=True)

    def _apply_theme(self):
        self._load_background_theme()
        self.configure(bg=self.TABLE_DARK)
        self.canvas.configure(bg=self.TABLE)
        self.bottom.configure(bg=self.TABLE_DARK)
        self.hint.configure(bg=self.TABLE_DARK)
        self.draw()

    def _new_game_initial(self):
        self.store.record_started(self.current_difficulty)
        self.draw()

    def _abandon(self, title, msg):
        if self.game.moves > 0 and not self.game.won:
            if not messagebox.askyesno(title, msg):
                return False
            self.store.record_loss(self.current_difficulty)
        return True

    def request_new_game(self):
        if self._abandon("New Game", "Start a new game? The current game will be abandoned."):
            self.start_new_game()

    def start_new_game(self):
        self.game = FreeCellGame(self.current_difficulty)
        self.clear_hint(reset_cycle=True)
        self.win_recorded = False
        self.store.record_started(self.current_difficulty)
        self.hint.config(text=f"{self.current_difficulty} FreeCell. Single-click a card or valid stack to make its best legal move.")
        self.draw()

    def change_difficulty(self, _e=None):
        new = self.diff_var.get()
        if new == self.current_difficulty:
            return
        if not self._abandon("Change Difficulty", f"Start a new {new} game?"):
            self.diff_var.set(self.current_difficulty)
            return
        self.current_difficulty = new
        self.store.settings["difficulty"] = new
        self.store.save_settings()
        self.start_new_game()

    def change_accent(self, _e=None):
        new = self.accent_var.get()
        if new in ACCENT_COLORS:
            self.accent_name = new
            self.store.settings["accent"] = new
            self.store.save_settings()
            self.draw()

    def change_background(self, _e=None):
        new = self.background_var.get()
        if new in BACKGROUND_COLORS:
            self.background_name = new
            self.store.settings["background"] = new
            self.store.save_settings()
            self._apply_theme()

    @staticmethod
    def fmt_time(sec):
        if sec is None:
            return "—"
        h, rem = divmod(int(sec), 3600)
        m, s = divmod(rem, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

    def _tick(self):
        self.status.config(
            text=(f"{self.current_difficulty}   |   Moves {self.game.moves}   •   "
                  f"Time {self.fmt_time(self.game.elapsed_seconds())}   •   "
                  f"Free Cells {self.game.empty_freecells()}/4   •   "
                  f"Foundations {sum(len(x) for x in self.game.foundations.values())}/52")
        )
        self.after(500, self._tick)

    def _foundation_safe(self, card: Card) -> bool:
        if card.rank <= 2:
            return True
        opposite = [s for s in SUITS if color_of(s) != color_of(card.suit)]
        same_color_other = [s for s in SUITS if color_of(s) == color_of(card.suit) and s != card.suit]
        opp_min = min(self.game.foundation_rank(s) for s in opposite)
        same_min = min((self.game.foundation_rank(s) for s in same_color_other), default=13)
        return opp_min >= card.rank - 1 and same_min >= card.rank - 2

    def _exposed_after_move_is_useful(self, src: int, idx: int) -> bool:
        if idx <= 0:
            return True
        exposed = self.game.cascades[src][idx - 1]
        if self.game.can_to_foundation(exposed):
            return True
        for dst in range(8):
            if dst == src:
                continue
            target = self.game.cascades[dst]
            if target and target[-1].rank == exposed.rank + 1 and color_of(target[-1].suit) != color_of(exposed.suit):
                return True
        return False

    def _cascade_move_score(self, src: int, idx: int, dst: int):
        seq_len = len(self.game.cascades[src]) - idx
        target = self.game.cascades[dst]
        empties_source = idx == 0
        exposes_useful = self._exposed_after_move_is_useful(src, idx)
        score = 250
        if target:
            score += 800
        else:
            score += 70
        if empties_source:
            score += 1150
        elif exposes_useful:
            score += 520
        # Do not recommend hauling big built sequences around without a reason.
        score -= max(0, seq_len - 1) * 170
        if seq_len >= 4 and not empties_source and not exposes_useful:
            score -= 1000
        if not target and not empties_source:
            score -= 300
        return score, {"seq_len": seq_len, "empties_source": empties_source, "exposes_useful": exposes_useful}

    def _legal_hint_actions(self):
        actions = []
        # Safe foundation moves are usually the clearest progress.
        for cell, c in enumerate(self.game.freecells):
            if c is not None and self.game.can_to_foundation(c):
                score = 2800 if self._foundation_safe(c) else 1200
                actions.append((score, "cellf", (cell, c.suit), {"card": c}))
            if c is not None:
                ranked = [d for d in range(8) if self.game.cascades[d] and self.game.can_freecell_to_cascade(cell, d)]
                for dst in ranked:
                    actions.append((2100, "cellc", (cell, dst), {"card": c, "frees_cell": True}))

        for src, col in enumerate(self.game.cascades):
            if not col:
                continue
            top = col[-1]
            if self.game.can_to_foundation(top):
                score = 2600 if self._foundation_safe(top) else 1050
                actions.append((score, "cf", (src, top.suit), {"card": top}))

            for idx, c in enumerate(col):
                if not self.game.movable_sequence(src, idx):
                    continue
                legal = [d for d in range(8) if self.game.can_cascade_to_cascade(src, idx, d)]
                ranked = [d for d in legal if self.game.cascades[d]]
                # Do not produce eight variants whose only point is "use an empty column".
                hint_dests = ranked if ranked else (legal[:1] if legal else [])
                for dst in hint_dests:
                    score, meta = self._cascade_move_score(src, idx, dst)
                    actions.append((score, "cc", (src, idx, dst), meta))

            # Parking one top card in a free cell is a fallback hint, especially
            # when it exposes a card that can immediately be used.
            if self.game.empty_freecells() and col:
                idx = len(col) - 1
                useful = self._exposed_after_move_is_useful(src, idx)
                score = 900 + (500 if useful else 0)
                cell = next(i for i, c in enumerate(self.game.freecells) if c is None)
                actions.append((score, "cfc", (src, cell), {"card": top, "exposes_useful": useful}))

        actions.sort(key=lambda x: (-x[0], x[1], x[2]))
        return actions

    def _board_signature(self):
        return (
            tuple(tuple((c.rank, c.suit) for c in col) for col in self.game.cascades),
            tuple((c.rank, c.suit) if c else None for c in self.game.freecells),
            tuple((s, self.game.foundation_rank(s)) for s in SUITS),
        )

    def show_hint(self):
        sig = self._board_signature()
        if sig != self.hint_board_signature:
            self.hint_board_signature = sig
            self.hint_cycle_index = 0
        else:
            self.hint_cycle_index += 1
        self.clear_hint(reset_cycle=False)
        actions = self._legal_hint_actions()
        useful = [a for a in actions if a[0] >= 900]
        choices = useful if useful else actions
        if not choices:
            self.hint.config(text="No legal move is available.")
            return
        _score, kind, payload, meta = choices[self.hint_cycle_index % len(choices)]
        self.hint_kind, self.hint_payload = kind, payload
        if kind == "cc":
            s, i, d = payload
            c = self.game.cascades[s][i]
            extra = " to open a column." if meta.get("empties_source") else ""
            self.hint.config(text=f"Hint: move {rank_text(c.rank)}{c.suit} to column {d+1}{extra}")
        elif kind == "cf":
            s, _suit = payload
            c = self.game.cascades[s][-1]
            self.hint.config(text=f"Hint: move {rank_text(c.rank)}{c.suit} to its foundation.")
        elif kind == "cfc":
            s, cell = payload
            c = self.game.cascades[s][-1]
            self.hint.config(text=f"Hint: move {rank_text(c.rank)}{c.suit} into Free Cell {cell+1}.")
        elif kind == "cellc":
            cell, d = payload
            c = self.game.freecells[cell]
            self.hint.config(text=f"Hint: move {rank_text(c.rank)}{c.suit} from Free Cell {cell+1} to column {d+1}.")
        elif kind == "cellf":
            cell, _suit = payload
            c = self.game.freecells[cell]
            self.hint.config(text=f"Hint: move {rank_text(c.rank)}{c.suit} from Free Cell {cell+1} to its foundation.")
        self._start_hint_animation()
        self.draw()

    def clear_hint(self, reset_cycle=True):
        if self.hint_anim_job:
            try:
                self.after_cancel(self.hint_anim_job)
            except tk.TclError:
                pass
        self.hint_anim_job = None
        self.hint_kind = None
        self.hint_payload = None
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        if reset_cycle:
            self.hint_board_signature = None
            self.hint_cycle_index = 0

    def _start_hint_animation(self):
        if self.hint_anim_job:
            try:
                self.after_cancel(self.hint_anim_job)
            except tk.TclError:
                pass
        self.hint_anim_phase = 0.0
        self.hint_anim_cycles = 0
        self.hint_anim_finished = False
        self.hint_anim_job = self.after(70, self._animate_hint)

    def _animate_hint(self):
        self.hint_anim_job = None
        if not self.hint_kind or self.hint_anim_finished:
            return
        p = self.hint_anim_phase + 0.055
        if p >= 1.0:
            self.hint_anim_cycles += 1
            if self.hint_anim_cycles >= 3:
                self.hint_anim_phase = 1.0
                self.hint_anim_finished = True
                self.draw()
                return
            p -= 1.0
        self.hint_anim_phase = p
        self.draw()
        self.hint_anim_job = self.after(70, self._animate_hint)

    def auto_complete(self):
        self.clear_hint()
        moved = self.game.auto_complete_foundations()
        if moved:
            self.hint.config(text=f"Auto Complete moved {moved} card{'s' if moved != 1 else ''} to the foundations." + (" Game complete!" if self.game.won else ""))
            self.draw()
        else:
            self.hint.config(text="Auto Complete: no exposed card can move to a foundation yet.")

    def undo(self):
        if self.game.undo():
            self.clear_hint()
            self.win_recorded = False
            self.hint.config(text="Move undone.")
            self.draw()
        else:
            self.hint.config(text="Nothing to undo yet.")

    def _layout(self):
        w = max(700, self.canvas.winfo_width())
        h = max(420, self.canvas.winfo_height())
        margin = max(12, min(38, int(w * 0.022)))
        gap = max(8, min(24, int(w * 0.009)))
        cw = int((w - 2 * margin - 7 * gap) / 8)
        cw = max(62, min(160, cw))
        ch = int(cw * 1.40)
        total = 8 * cw + 7 * gap
        x0 = (w - total) // 2
        top_y = max(16, int(ch * 0.07))
        tableau_y = top_y + ch + max(28, int(ch * 0.20))
        return w, h, x0, top_y, tableau_y, cw, ch, gap

    def draw(self):
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("all")
        self.card_rects.clear()
        self.freecell_rects.clear()
        self.foundation_rects.clear()
        self.hitboxes.clear()
        self.cascade_drop_rects.clear()

        w, h, x0, top_y, y0, cw, ch, gap = self._layout()
        accent = ACCENT_COLORS[self.accent_name]

        # Four Free Cells on the left.
        for cell in range(4):
            x = x0 + cell * (cw + gap)
            rect = (x, top_y, x + cw, top_y + ch)
            self.freecell_rects[cell] = rect
            c = self.game.freecells[cell]
            if c is None:
                self._slot(x, top_y, cw, ch, "", outline=accent)
                self.canvas.create_text(x + cw/2, top_y + ch/2, text="FREE", fill=self.SLOT_EDGE,
                                        font=("DejaVu Sans", max(9, int(cw * .10)), "bold"))
            else:
                self.draw_card(x, top_y, cw, ch, c)

        # Four suit foundations on the right.
        for n, suit in enumerate(SUITS):
            x = x0 + (n + 4) * (cw + gap)
            rect = (x, top_y, x + cw, top_y + ch)
            self.foundation_rects[suit] = rect
            pile = self.game.foundations[suit]
            if pile:
                self.draw_card(x, top_y, cw, ch, pile[-1])
            else:
                self._slot(x, top_y, cw, ch, suit)

        max_cards = max((len(c) for c in self.game.cascades), default=1)
        avail = max(170, h - y0 - 18)
        step = max(22, min(52, int(cw * .31)))
        est = ch + max(0, max_cards - 1) * step
        if est > avail:
            step = max(16, int(step * avail / est))

        for ci, col in enumerate(self.game.cascades):
            x = x0 + ci * (cw + gap)
            if not col:
                self._slot(x, y0, cw, ch, "", outline=accent)
                self.cascade_drop_rects[ci] = (x, y0, x + cw, y0 + ch)
                self.hitboxes.append((x, y0, x + cw, y0 + ch, "empty", ci, -1))
                continue
            y = y0
            for idx, c in enumerate(col):
                last = idx == len(col) - 1
                self.draw_card(x, y, cw, ch, c)
                self.card_rects[(ci, idx)] = (x, y, x + cw, y + ch)
                hit_bottom = y + (ch if last else step)
                self.hitboxes.append((x, y, x + cw, hit_bottom, "cascade", ci, idx))
                y += step
            self.cascade_drop_rects[ci] = (x, y, x + cw, y + ch)

        self._draw_hint_overlay(cw, ch)
        if self.game.won and not self.win_recorded:
            self.win_recorded = True
            self.store.record_win(self.current_difficulty, self.game.elapsed_seconds(), self.game.moves)
            self.after(150, self.show_win)

    def _slot(self, x, y, w, h, text="", outline=None):
        outline = outline or self.SLOT_EDGE
        self._rounded_rect(x, y, x+w, y+h, max(5, int(w/15)), outline=outline, width=2, dash=(5, 4))
        if text:
            self.canvas.create_text(x+w/2, y+h/2, text=text, fill=self.SLOT_EDGE,
                                    font=("DejaVu Sans", max(18, int(w*.28)), "bold"))

    def _rounded_rect(self, x1, y1, x2, y2, r, **kwargs):
        r = max(2, int(r))
        kwargs.setdefault("fill", "")
        pts = [int(x1+r), int(y1), int(x2-r), int(y1), int(x2), int(y1+r), int(x2), int(y2-r),
               int(x2-r), int(y2), int(x1+r), int(y2), int(x1), int(y2-r), int(x1), int(y1+r)]
        return self.canvas.create_polygon(pts, smooth=False, **kwargs)

    def draw_card(self, x, y, w, h, c: Card, ghost=False):
        r = max(4, int(w)//15)
        sh = max(1, int(w*.02))
        if not ghost:
            self._rounded_rect(x+sh, y+sh*2, x+w+sh, y+h+sh*2, r, fill=self.CARD_SHADOW, outline="")
        self._rounded_rect(x, y, x+w, y+h, r, fill=self.CARD_FACE, outline=self.CARD_EDGE, width=max(1, int(w*.009)))
        fg = SUIT_COLORS[c.suit]
        fs = max(11, int(w*.205))
        left = x + max(8, w*.13)
        self.canvas.create_text(left, y+max(11, h*.095), text=rank_text(c.rank), fill=fg,
                                font=("DejaVu Sans", fs, "bold"))
        self.canvas.create_text(left, y+max(26, h*.225), text=c.suit, fill=fg,
                                font=("DejaVu Sans", max(11, int(w*.19)), "bold"))
        if h >= 70:
            self.canvas.create_text(x+w/2, y+h*.61, text=c.suit, fill=fg,
                                    font=("DejaVu Sans", max(22, int(w*.42)), "bold"))

    def _outline_rect(self, rect, color, width=4):
        x1, y1, x2, y2 = rect
        self._rounded_rect(x1-2, y1-2, x2+2, y2+2, max(6, int((x2-x1)/15)), outline=color, width=width)

    def _hint_geometry(self):
        k, p = self.hint_kind, self.hint_payload
        if not k:
            return None
        if k == "cc":
            s, i, d = p
            src = self.card_rects.get((s, i))
            dst = self.cascade_drop_rects.get(d)
            c = self.game.cascades[s][i]
        elif k == "cf":
            s, suit = p
            src = self.card_rects.get((s, len(self.game.cascades[s])-1))
            dst = self.foundation_rects.get(suit)
            c = self.game.cascades[s][-1] if self.game.cascades[s] else None
        elif k == "cfc":
            s, cell = p
            src = self.card_rects.get((s, len(self.game.cascades[s])-1))
            dst = self.freecell_rects.get(cell)
            c = self.game.cascades[s][-1] if self.game.cascades[s] else None
        elif k == "cellc":
            cell, d = p
            src = self.freecell_rects.get(cell)
            dst = self.cascade_drop_rects.get(d)
            c = self.game.freecells[cell]
        elif k == "cellf":
            cell, suit = p
            src = self.freecell_rects.get(cell)
            dst = self.foundation_rects.get(suit)
            c = self.game.freecells[cell]
        else:
            return None
        return src, dst, c

    def _draw_hint_overlay(self, cw, ch):
        if not self.hint_kind:
            return
        geo = self._hint_geometry()
        if not geo:
            return
        src, dst, c = geo
        if not src or not dst or c is None:
            return
        self._outline_rect(src, self.HINT_SOURCE, 4)
        self._outline_rect(dst, self.HINT_DEST, 4)
        sx, sy = (src[0]+src[2])/2, (src[1]+src[3])/2
        dx, dy = (dst[0]+dst[2])/2, (dst[1]+dst[3])/2
        self.canvas.create_line(sx, sy, dx, dy, fill=self.HINT_DEST, width=max(2, int(cw*.025)),
                                arrow="last", arrowshape=(12, 14, 5), dash=(8, 5))
        if not self.hint_anim_finished:
            t = self.hint_anim_phase
            t = t*t*(3-2*t)
            x = src[0]*(1-t) + dst[0]*t
            y = src[1]*(1-t) + dst[1]*t
            self.draw_card(x, y, cw, ch, Card(c.rank, c.suit), ghost=True)
            self._rounded_rect(x, y, x+cw, y+ch, max(5, int(cw/15)), outline=self.HINT_SOURCE, width=4)

    def _best_cascade_destination(self, src: int, idx: int):
        legal = [d for d in range(8) if self.game.can_cascade_to_cascade(src, idx, d)]
        if not legal:
            return None
        ranked = [d for d in legal if self.game.cascades[d]]
        candidates = ranked if ranked else legal
        scored = []
        for d in candidates:
            score, _ = self._cascade_move_score(src, idx, d)
            scored.append((score, -d, d))
        return max(scored)[2]

    def _best_freecell_destination(self, cell: int):
        c = self.game.freecells[cell]
        if c is None:
            return None
        if self.game.can_to_foundation(c) and self._foundation_safe(c):
            return ("foundation", c.suit)
        ds = [d for d in range(8) if self.game.can_freecell_to_cascade(cell, d)]
        if ds:
            ranked = [d for d in ds if self.game.cascades[d]]
            return ("cascade", (ranked if ranked else ds)[0])
        if self.game.can_to_foundation(c):
            return ("foundation", c.suit)
        return None

    def _best_foundation_destination(self, suit: str):
        legal = [d for d in range(8) if self.game.can_foundation_to_cascade(suit, d)]
        ranked = [d for d in legal if self.game.cascades[d]]
        return (ranked if ranked else legal)[0] if legal else None

    def on_click(self, e):
        x, y = e.x, e.y

        for cell, rect in self.freecell_rects.items():
            if rect[0] <= x <= rect[2] and rect[1] <= y <= rect[3]:
                c = self.game.freecells[cell]
                if c is None:
                    self.hint.config(text=f"Free Cell {cell+1} is empty. A single top card can be parked here.")
                    return
                dest = self._best_freecell_destination(cell)
                if not dest:
                    self.hint.config(text="That Free Cell card has no useful legal destination.")
                    return
                ok = self.game.move_freecell_to_foundation(cell) if dest[0] == "foundation" else self.game.move_freecell_to_cascade(cell, dest[1])
                if ok:
                    self.clear_hint()
                    self.hint.config(text="Moved the Free Cell card.")
                    self.draw()
                return

        for suit, rect in self.foundation_rects.items():
            if rect[0] <= x <= rect[2] and rect[1] <= y <= rect[3] and self.game.foundations[suit]:
                dst = self._best_foundation_destination(suit)
                if dst is not None and self.game.move_foundation_to_cascade(suit, dst):
                    self.clear_hint()
                    self.hint.config(text="Moved a foundation card back to the tableau.")
                    self.draw()
                else:
                    self.hint.config(text="That foundation card has no legal tableau destination.")
                return

        hit = None
        for hb in reversed(self.hitboxes):
            x1, y1, x2, y2, kind, col, idx = hb
            if x1 <= x <= x2 and y1 <= y <= y2:
                hit = (kind, col, idx)
                break
        if not hit:
            return
        kind, col, idx = hit
        if kind == "empty":
            self.hint.config(text="Empty column: any card or valid descending alternating-colour stack may use it.")
            return

        c = self.game.cascades[col][idx]
        is_top = idx == len(self.game.cascades[col]) - 1
        seq_ok = self.game.movable_sequence(col, idx)
        dst = self._best_cascade_destination(col, idx) if seq_ok else None

        # Safe foundation first for a single top card, then a proper ranked build.
        if is_top and self.game.can_to_foundation(c) and self._foundation_safe(c):
            if self.game.move_cascade_to_foundation(col):
                self.clear_hint()
                self.hint.config(text=f"Moved {rank_text(c.rank)}{c.suit} to its foundation.")
                self.draw()
                return

        if dst is not None and self.game.cascades[dst]:
            if self.game.move_cascade_to_cascade(col, idx, dst):
                self.clear_hint()
                self.hint.config(text=f"Moved to column {dst+1}.")
                self.draw()
                return

        # A free cell is a better parking place for one card than consuming an
        # empty cascade, so use it before an empty-column fallback.
        if is_top:
            empty_cell = next((i for i, fc in enumerate(self.game.freecells) if fc is None), None)
            if empty_cell is not None and self.game.move_cascade_to_freecell(col, empty_cell):
                self.clear_hint()
                self.hint.config(text=f"Moved {rank_text(c.rank)}{c.suit} into Free Cell {empty_cell+1}.")
                self.draw()
                return

        if dst is not None and self.game.move_cascade_to_cascade(col, idx, dst):
            self.clear_hint()
            self.hint.config(text=f"Moved to column {dst+1}.")
            self.draw()
            return

        if is_top and self.game.can_to_foundation(c) and self.game.move_cascade_to_foundation(col):
            self.clear_hint()
            self.hint.config(text=f"Moved {rank_text(c.rank)}{c.suit} to its foundation.")
            self.draw()
            return

        self.hint.config(text="No legal destination is available for that card or stack.")

    def show_win(self):
        win = tk.Toplevel(self)
        win.title("You won!")
        win.transient(self)
        win.resizable(False, False)
        try:
            if self._icon_image is not None:
                win.iconphoto(True, self._icon_image)
        except tk.TclError:
            pass
        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="You won!", font=("DejaVu Sans", 18, "bold")).pack(pady=(0, 10))
        ttk.Label(frame, text=f"Difficulty: {self.current_difficulty}\nTime: {self.fmt_time(self.game.elapsed_seconds())}\nMoves: {self.game.moves}",
                  justify="center", font=("DejaVu Sans", 11)).pack(pady=(0, 18))
        buttons = ttk.Frame(frame)
        buttons.pack()

        def newg():
            win.destroy()
            self.start_new_game()

        ttk.Button(buttons, text="New Game", command=newg).pack(side="left", padx=(0, 10))
        ttk.Button(buttons, text="OK", command=win.destroy).pack(side="left")
        win.bind("<Return>", lambda _e: win.destroy())
        win.bind("<Escape>", lambda _e: win.destroy())
        win.update_idletasks()
        win.geometry(f"+{self.winfo_rootx()+max(0,(self.winfo_width()-win.winfo_reqwidth())//2)}+{self.winfo_rooty()+max(0,(self.winfo_height()-win.winfo_reqheight())//2)}")
        win.grab_set()
        win.focus_force()

    def show_statistics(self):
        win = tk.Toplevel(self)
        win.title("Statistics")
        win.transient(self)
        win.minsize(610, 270)
        f = ttk.Frame(win, padding=16)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="FreeCell Statistics", font=("DejaVu Sans", 15, "bold")).grid(row=0, column=0, columnspan=7, sticky="w", pady=(0, 12))
        headers = ["Difficulty", "Played", "Won", "Win rate", "Best time", "Fewest moves", "Best streak"]
        for c, text in enumerate(headers):
            ttk.Label(f, text=text, font=("DejaVu Sans", 9, "bold")).grid(row=1, column=c, padx=7, pady=4, sticky="w")
        r = 2
        for diff in DIFFICULTIES:
            s = self.store.get(diff)
            rate = f"{100*s['won']/s['played']:.1f}%" if s["played"] else "0.0%"
            vals = [diff, s["played"], s["won"], rate, self.fmt_time(s["best_time"]), s["fewest_moves"] if s["fewest_moves"] is not None else "—", s["best_streak"]]
            for c, v in enumerate(vals):
                ttk.Label(f, text=str(v)).grid(row=r, column=c, padx=7, pady=4, sticky="w")
            r += 1
        bb = ttk.Frame(f)
        bb.grid(row=r, column=0, columnspan=7, sticky="e", pady=(14, 0))
        ttk.Button(bb, text="Reset Statistics", command=lambda: self._reset_stats(win)).pack(side="left", padx=(0, 8))
        ttk.Button(bb, text="Close", command=win.destroy).pack(side="left")

    def _reset_stats(self, win):
        if messagebox.askyesno("Reset Statistics", "Reset all FreeCell statistics?", parent=win):
            self.store.reset_stats()
            win.destroy()
            self.show_statistics()

    def on_close(self):
        if self.hint_anim_job:
            try:
                self.after_cancel(self.hint_anim_job)
            except tk.TclError:
                pass
        self.store.settings.update({
            "difficulty": self.current_difficulty,
            "accent": self.accent_name,
            "background": self.background_name,
        })
        self.store.save_settings()
        self.destroy()


if __name__ == "__main__":
    FreeCellApp().mainloop()
